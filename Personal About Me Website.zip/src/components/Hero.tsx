import { Github, Linkedin, Mail } from "lucide-react";
import { Button } from "./ui/button";
import profileImg from "figma:asset/d8fd7b8c3f11e972fd8dc8742b15a41d628a7f12.png";

export function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center px-4 py-20">
      <div className="absolute inset-0 bg-gradient-to-br from-blue-600/10 via-purple-600/10 to-pink-600/10" />
      
      <div className="relative max-w-4xl mx-auto text-center space-y-8">
        <div className="inline-block">
          <div className="w-48 h-48 mx-auto mb-6 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 p-1.5 shadow-2xl">
            <div className="w-full h-full rounded-full overflow-hidden bg-white">
              <img 
                src={profileImg}
                alt="Gauri Maruti Chile"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
        
        <div className="space-y-4">
          <h1 className="text-5xl md:text-7xl bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-purple-600">
            Gauri Maruti Chile
          </h1>
          <p className="text-xl md:text-2xl text-slate-600">
            Computer Engineering Student
          </p>
          <p className="text-slate-500 max-w-2xl mx-auto">
            First Year Student at Fr. Conceicao Rodrigues College of Engineering, Bandra
          </p>
        </div>

        <div className="flex gap-4 justify-center flex-wrap">
          <Button className="gap-2">
            <Mail className="w-4 h-4" />
            Contact Me
          </Button>
          <Button variant="outline" className="gap-2">
            <Github className="w-4 h-4" />
            GitHub
          </Button>
          <Button variant="outline" className="gap-2">
            <Linkedin className="w-4 h-4" />
            LinkedIn
          </Button>
        </div>
      </div>
    </section>
  );
}