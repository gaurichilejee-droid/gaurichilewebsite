import { Trophy, Award, Star, Medal, BookOpen, Target } from "lucide-react";
import { Card, CardContent } from "./ui/card";
import scholarshipImg from "figma:asset/e443cfcaadf59ad0cf9949bc499ef4ca5a1153a1.png";
import roadSafetyImg from "figma:asset/9e254606f1fc92a7f790665a4d9d47cdcae4b04c.png";
import timesIndiaImg from "figma:asset/5b743eb8b794a65477e91b977f3a5169b1976177.png";
import sciTechExcellenceImg from "figma:asset/20f5cd713a6b77369c7ec47cfcac5c827eb7a5b3.png";
import studentOfYearImg from "figma:asset/1bed731e3f1097df5dfe132f779e171578af2c15.png";
import sscExcellenceImg from "figma:asset/6977b1ed28d7142709dd02b6cfcb3f55498415d4.png";

const achievements = [
  {
    title: "Certificate of Excellence - Science & Technology",
    description: "98/100 in S.S.C Examination 2022-2023",
    details: "Awarded Certificate of Excellence by St. Paul's Convent High School for outstanding performance, scoring 98/100 in Science & Technology in the S.S.C Examination 2022-2023.",
    image: sciTechExcellenceImg,
    icon: Trophy,
    color: "from-amber-400 to-yellow-600"
  },
  {
    title: "Times of India Student of the Year",
    description: "Fourth Rank - Academic Performance 2021-22",
    details: "Recognized by Times of India as Student of the Year for outstanding academic performance, securing FOURTH RANK in the entire school for 2021-22.",
    image: studentOfYearImg,
    icon: Medal,
    color: "from-red-500 to-rose-600"
  },
  {
    title: "Certificate of Excellence - Consistent Performance",
    description: "Rank 9th, 6th, 6th in S.S.C Examination 2022-2023",
    details: "Awarded by St. Paul's Convent High School for consistent excellence, achieving ranks of 9th, 6th, and 6th in the S.S.C Examination 2022-2023.",
    image: sscExcellenceImg,
    icon: Target,
    color: "from-emerald-400 to-green-600"
  },
  {
    title: "Vidyalankar Scholarship Award",
    description: "Student of the Year 2022-23 - Rank 3",
    details: "Awarded 65% tuition waiver scholarship for pursuing Vidyalankar's 2 year Program in recognition of Excellent Academic Achievement at St. Paul's Convent High School.",
    image: scholarshipImg,
    icon: Trophy,
    color: "from-yellow-400 to-orange-500"
  },
  {
    title: "Road Safety Patrol Course",
    description: "Mumbai Road Safety Patrol (2020-2023)",
    details: "Successfully completed the Road Safety Patrol Course conducted by RSP Mumbai, demonstrating commitment to community safety and responsibility.",
    image: roadSafetyImg,
    icon: Award,
    color: "from-blue-400 to-indigo-500"
  },
  {
    title: "Times NIE National Aptitude Challenge",
    description: "Participated in NAC 2017-18",
    details: "Participated in Times NIE National Aptitude Challenge, showcasing analytical and problem-solving abilities at the national level.",
    image: timesIndiaImg,
    icon: Star,
    color: "from-purple-400 to-pink-500"
  }
];

export function Achievements() {
  return (
    <section className="py-20 px-4 bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl mb-4 bg-clip-text text-transparent bg-gradient-to-r from-yellow-600 via-orange-600 to-red-600">
            Achievements & Recognition
          </h2>
          <p className="text-slate-600 text-lg max-w-2xl mx-auto">
            A collection of accomplishments and certifications earned throughout my academic journey
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {achievements.map((achievement, index) => {
            const Icon = achievement.icon;
            return (
              <Card 
                key={index}
                className="group overflow-hidden hover:shadow-2xl transition-all duration-300 hover:-translate-y-2"
              >
                <div className="relative h-64 overflow-hidden bg-slate-100">
                  <img 
                    src={achievement.image}
                    alt={achievement.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute top-4 right-4">
                    <div className={`w-12 h-12 rounded-full bg-gradient-to-br ${achievement.color} p-2.5 shadow-lg`}>
                      <Icon className="w-full h-full text-white" />
                    </div>
                  </div>
                </div>
                
                <CardContent className="p-6 space-y-3">
                  <h3 className="text-xl">
                    {achievement.title}
                  </h3>
                  <p className={`bg-gradient-to-r ${achievement.color} bg-clip-text text-transparent`}>
                    {achievement.description}
                  </p>
                  <p className="text-slate-600 text-sm">
                    {achievement.details}
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}