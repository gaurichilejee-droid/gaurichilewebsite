import { Palette, Sparkles, Heart, Lightbulb, Lamp, Flower } from "lucide-react";
import artworkImg1 from "figma:asset/d4f019034dbed221242b8daa2501dee84789235a.png";
import artworkImg2 from "figma:asset/1a7050919850dc58a8ccb554920f38daa7d073f5.png";
import artworkImg3 from "figma:asset/f0ceb2f4b69d8449d31c81cd9fdc298eb90da7cf.png";
import decorLightImg from "figma:asset/6e12e78cd39b10f63505482d2126a342c9c31377.png";
import lanternImg from "figma:asset/0ffb78f800cd644f54fa0965946a54ed8c4c2af6.png";
import gardeningImg from "figma:asset/c8c5e709a8a2f041b2ade19257386942cf341c0b.png";

const interests = [
  {
    title: "Abstract Art",
    description: "Exploring colors and forms through creative expression",
    image: artworkImg1,
    icon: Palette,
    color: "from-pink-500 to-purple-600"
  },
  {
    title: "Cultural Art",
    description: "Appreciating traditional and spiritual artwork",
    image: artworkImg2,
    icon: Sparkles,
    color: "from-blue-500 to-orange-500"
  },
  {
    title: "Nature & Landscapes",
    description: "Finding inspiration in natural beauty",
    image: artworkImg3,
    icon: Heart,
    color: "from-orange-500 to-yellow-500"
  },
  {
    title: "Decorative Lights",
    description: "Creating ambiance with beautiful illumination",
    image: decorLightImg,
    icon: Lightbulb,
    color: "from-amber-400 to-orange-500"
  },
  {
    title: "Festive Decorations",
    description: "Celebrating with colorful and creative decor",
    image: lanternImg,
    icon: Lamp,
    color: "from-fuchsia-500 to-pink-600"
  },
  {
    title: "Gardening",
    description: "Nurturing plants and connecting with nature",
    image: gardeningImg,
    icon: Flower,
    color: "from-emerald-500 to-green-600"
  }
];

export function Interests() {
  return (
    <section className="py-20 px-4 bg-white/50">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl mb-4 bg-clip-text text-transparent bg-gradient-to-r from-pink-600 via-purple-600 to-blue-600">
            Hobbies & Interests
          </h2>
          <p className="text-slate-600 text-lg max-w-2xl mx-auto">
            Beyond academics, I enjoy expressing creativity through art and exploring various forms of artistic expression
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {interests.map((interest, index) => {
            const Icon = interest.icon;
            return (
              <div
                key={index}
                className="group relative overflow-hidden rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2"
              >
                <div className="relative h-80 overflow-hidden">
                  <img 
                    src={interest.image}
                    alt={interest.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />
                  
                  <div className="absolute top-4 right-4">
                    <div className={`w-12 h-12 rounded-full bg-gradient-to-br ${interest.color} p-2.5 shadow-lg backdrop-blur-sm`}>
                      <Icon className="w-full h-full text-white" />
                    </div>
                  </div>
                  
                  <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                    <h3 className="text-2xl mb-2">
                      {interest.title}
                    </h3>
                    <p className="text-slate-200">
                      {interest.description}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}