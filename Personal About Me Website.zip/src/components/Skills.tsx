import { Code, Database, Laptop, Brain, BookOpen, Users } from "lucide-react";

const skills = [
  {
    icon: Code,
    title: "Programming",
    description: "Learning programming fundamentals and various languages",
    color: "from-blue-500 to-cyan-500"
  },
  {
    icon: Database,
    title: "Data Structures",
    description: "Understanding algorithms and data organization",
    color: "from-purple-500 to-pink-500"
  },
  {
    icon: Laptop,
    title: "Web Development",
    description: "Exploring modern web technologies and frameworks",
    color: "from-green-500 to-emerald-500"
  },
  {
    icon: Brain,
    title: "Problem Solving",
    description: "Developing analytical and logical thinking skills",
    color: "from-orange-500 to-red-500"
  },
  {
    icon: BookOpen,
    title: "Continuous Learning",
    description: "Staying updated with latest tech trends",
    color: "from-indigo-500 to-blue-500"
  },
  {
    icon: Users,
    title: "Teamwork",
    description: "Collaborating on projects and sharing knowledge",
    color: "from-pink-500 to-rose-500"
  }
];

export function Skills() {
  return (
    <section className="py-20 px-4">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl md:text-5xl text-center mb-12 bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-purple-600">
          Skills & Interests
        </h2>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {skills.map((skill, index) => {
            const Icon = skill.icon;
            return (
              <div
                key={index}
                className="group p-6 bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
              >
                <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${skill.color} p-2.5 mb-4 group-hover:scale-110 transition-transform`}>
                  <Icon className="w-full h-full text-white" />
                </div>
                <h3 className="text-xl mb-2">{skill.title}</h3>
                <p className="text-slate-600">{skill.description}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
