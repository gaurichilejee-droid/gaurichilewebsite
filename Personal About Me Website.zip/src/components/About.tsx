import { ImageWithFallback } from "./figma/ImageWithFallback";

export function About() {
  return (
    <section className="py-20 px-4">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl md:text-5xl text-center mb-12 bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-purple-600">
          About Me
        </h2>
        
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <p className="text-slate-700">
              Hello! I'm Gauri Maruti Chile, a passionate first-year Computer Engineering student at Fr. Conceicao Rodrigues College of Engineering in Bandra. I'm embarking on an exciting journey into the world of technology and innovation.
            </p>
            
            <p className="text-slate-700">
              As I begin my academic journey in computer engineering, I'm eager to explore various aspects of technology, from software development to artificial intelligence. I believe in continuous learning and staying updated with the latest technological advancements.
            </p>
            
            <p className="text-slate-700">
              My goal is to become a skilled engineer who can contribute meaningfully to solving real-world problems through technology. I'm particularly interested in learning programming, algorithms, and how technology can make a positive impact on society.
            </p>
          </div>
          
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl transform rotate-3" />
            <div className="relative bg-white rounded-2xl overflow-hidden shadow-xl transform -rotate-1 hover:rotate-0 transition-transform duration-300">
              <ImageWithFallback 
                src="https://images.unsplash.com/photo-1701576766277-c6160505581d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHVkZW50JTIwc3R1ZHlpbmclMjBsYXB0b3B8ZW58MXx8fHwxNzYzODY0NjY5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Student studying"
                className="w-full h-80 object-cover"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
