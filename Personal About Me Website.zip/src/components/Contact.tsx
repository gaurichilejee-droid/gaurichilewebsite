import { Mail, Github, Linkedin, Twitter } from "lucide-react";
import { Button } from "./ui/button";

export function Contact() {
  return (
    <section className="py-20 px-4 bg-gradient-to-br from-blue-600 to-purple-600">
      <div className="max-w-4xl mx-auto text-center space-y-8">
        <h2 className="text-4xl md:text-5xl text-white">
          Let's Connect!
        </h2>
        
        <p className="text-xl text-blue-100 max-w-2xl mx-auto">
          I'm always excited to connect with fellow students, professionals, and anyone interested in technology. Feel free to reach out!
        </p>
        
        <div className="flex gap-4 justify-center flex-wrap">
          <Button size="lg" variant="secondary" className="gap-2">
            <Mail className="w-5 h-5" />
            Email Me
          </Button>
          <Button size="lg" variant="outline" className="gap-2 bg-transparent text-white border-white hover:bg-white/10">
            <Github className="w-5 h-5" />
            GitHub
          </Button>
          <Button size="lg" variant="outline" className="gap-2 bg-transparent text-white border-white hover:bg-white/10">
            <Linkedin className="w-5 h-5" />
            LinkedIn
          </Button>
          <Button size="lg" variant="outline" className="gap-2 bg-transparent text-white border-white hover:bg-white/10">
            <Twitter className="w-5 h-5" />
            Twitter
          </Button>
        </div>
        
        <div className="pt-12 border-t border-white/20">
          <p className="text-blue-100">
            © 2024 Gauri Maruti Chile. Built with passion for learning and technology.
          </p>
        </div>
      </div>
    </section>
  );
}
