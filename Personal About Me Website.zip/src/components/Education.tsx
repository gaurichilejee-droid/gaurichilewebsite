import { GraduationCap, Calendar, MapPin } from "lucide-react";
import { Card, CardContent } from "./ui/card";
import collegeImg from "figma:asset/a0d9bee78b307c11af3bb7d269cbaab6bfde034b.png";

export function Education() {
  return (
    <section className="py-20 px-4 bg-white/50">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl md:text-5xl text-center mb-12 bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-purple-600">
          Education
        </h2>
        
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <Card className="overflow-hidden border-2 hover:shadow-xl transition-shadow">
            <div className="relative h-48 overflow-hidden">
              <img 
                src={collegeImg}
                alt="Fr. Conceicao Rodrigues College of Engineering"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
              <div className="absolute bottom-4 left-4 text-white">
                <GraduationCap className="w-12 h-12" />
              </div>
            </div>
            
            <CardContent className="p-6 space-y-4">
              <h3 className="text-2xl">
                Bachelor of Engineering
              </h3>
              <p className="text-xl text-blue-600">
                Computer Engineering
              </p>
              
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-slate-600">
                  <MapPin className="w-4 h-4" />
                  <span>Fr. Conceicao Rodrigues College of Engineering, Bandra</span>
                </div>
                
                <div className="flex items-center gap-2 text-slate-600">
                  <Calendar className="w-4 h-4" />
                  <span>First Year (2024-2025)</span>
                </div>
              </div>
              
              <p className="text-slate-600 pt-4 border-t">
                Pursuing comprehensive education in computer science fundamentals, programming, data structures, algorithms, and emerging technologies.
              </p>
            </CardContent>
          </Card>
          
          <div className="space-y-6">
            <div className="p-6 bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl border-2 border-blue-100">
              <h3 className="text-xl mb-2">🎯 Current Focus</h3>
              <p className="text-slate-700">
                Building strong foundations in programming, mathematics, and engineering principles while exploring various domains of computer science.
              </p>
            </div>
            
            <div className="p-6 bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl border-2 border-purple-100">
              <h3 className="text-xl mb-2">💡 Learning Journey</h3>
              <p className="text-slate-700">
                Engaging with coursework, practical projects, and staying curious about new technologies and innovations in the field.
              </p>
            </div>
            
            <div className="p-6 bg-gradient-to-br from-pink-50 to-blue-50 rounded-xl border-2 border-pink-100">
              <h3 className="text-xl mb-2">🚀 Future Goals</h3>
              <p className="text-slate-700">
                Aspiring to develop expertise in software development and contribute to meaningful technological solutions.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}