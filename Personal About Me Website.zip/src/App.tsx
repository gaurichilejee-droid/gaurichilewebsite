import { Hero } from "./components/Hero";
import { About } from "./components/About";
import { Education } from "./components/Education";
import { Achievements } from "./components/Achievements";
import { Skills } from "./components/Skills";
import { Interests } from "./components/Interests";
import { Contact } from "./components/Contact";

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <Hero />
      <About />
      <Education />
      <Achievements />
      <Skills />
      <Interests />
      <Contact />
    </div>
  );
}