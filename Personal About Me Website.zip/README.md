
  # Personal About Me Website

  This is a code bundle for Personal About Me Website. The original project is available at https://www.figma.com/design/6VZt05fYZ6PGkXIHrnugWH/Personal-About-Me-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  